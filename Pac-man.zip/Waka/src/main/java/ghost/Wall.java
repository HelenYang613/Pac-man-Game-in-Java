package ghost;

import processing.core.PImage;
import processing.core.PApplet;

public class Wall{

    /**
     * Record the row position of wall
     */
    private int x;

    /**
     * Record the column position of wall
     */
    private int y;

    /**
     * Save the wall picture
     */
    private PImage picture;

    /**
     * Constructor of Wall, contains three parameters
     * @param x The row position of wall
     * @param y The column position of wall
     * @param picture The picture of wall
     */
    public Wall(int x, int y, PImage picture){
        this.x = x;
        this.y = y;
        this.picture = picture;
    }

    /**
     * @return the row position of wall
     */
    public int getX(){
        return this.x;
    }

    /**
     * @return the column position of wall
     */
    public int getY(){
        return this.y;
    }

    /**
     * @return the width of picture
     */
    public int getWidth(){
        return this.picture.width;
    }

    /**
     * @return the height of picture
     */
    public int getHeight(){
        return this.picture.height;
    }

    /**
     * @param app The PApplet for draw image
     * Draw the prcture
     */
    public void draw(PApplet app){
        app.image(this.picture,this.x,this.y);
    }
}
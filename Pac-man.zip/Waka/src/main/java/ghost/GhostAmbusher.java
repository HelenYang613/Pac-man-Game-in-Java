package ghost;

import processing.core.PImage;
import processing.core.PApplet;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.lang.Math; 
import java.util.Random;

public class GhostAmbusher extends Ghost{

    /**
     * The Constructor of Ghost whim, contains six parameter
     * @param x the row position of ghost
     * @param y the column position of ghost
     * @param ghost the normal picture of ghost
     * @param frightenedPicture the frightened picture of ghost
     * @param walls the wall list
     * @param people the ghost type, is ambusher
     */

    public GhostAmbusher(int x, int y, PImage ghost, PImage frightenedPicture, List<Wall> walls, String people){
        super(x, y, ghost, frightenedPicture, walls, people);
        this.collision = false;
        this.invisiable = false;
        this.eaten = false;
    }

    /**
     * Change the ghost position under different mode
     * Under the Scatter mode, the destination of whim is the right up corner
     * Under the Chase mode, the destination of ignorant shoud be the player position
     * Under the frightened mode, the direction of ignorant is random
     */
    public void tick(){

        if(this.mode.equals("scatter")){

            if(this.direction != null){
                this.collision = this.checkCollision(this.x,this.y,this.direction);
            }

            if(this.next(this.x, this.y) || this.direction == null){
                this.direction = this.getNearStep(this.x, this.y, 0,0, this.direction);
            }

        }

        else if(this.mode.equals("chase")){

            if(this.next(this.x, this.y) || this.direction == null){

                if(this.player.getDirection().equals("left")){
                    this.direction = this.getNearStep(this.x, this.y, this.player.getX() - 4*16 , this.player.getY(), this.direction);
                    this.desx = this.player.getX() - 4 * 16;
                    this.desy = this.player.getY();
                }

                else if(this.player.getDirection().equals("right")){
                    this.direction = this.getNearStep(this.x, this.y, this.player.getX() + 4*16 , this.player.getY(), this.direction);
                    this.desx = this.player.getX() + 4 * 16;
                    this.desy = this.player.getY();
                }

                else if(this.player.getDirection().equals("up")){
                    this.direction = this.getNearStep(this.x, this.y, this.player.getX(), this.player.getY() - 4*16 , this.direction);
                    this.desx = this.player.getX();
                    this.desy = this.player.getY() - 4 * 16;
                }

                else if(this.player.getDirection().equals("down")){
                    this.direction = this.getNearStep(this.x, this.y, this.player.getX(), this.player.getY() + 4*16, this.direction);
                    this.desx = this.player.getX();
                    this.desy = this.player.getY() + 4 * 16;
                }
            }
        }

        else if(this.mode.equals("frightened")){

            if(this.next(this.x, this.y) || this.direction == null){

                List<String> validDiretion = this.validDirection(this.x, this.y, this.direction);

                Random r = new Random();

                int directionIndex = r.nextInt(validDiretion.size());
                
                this.direction = validDiretion.get(directionIndex);
            }
        }

        if(this.direction.equals("left")){
            this.x -= this.vel;
        }
        else if(this.direction.equals("right")){
            this.x += this.vel;
        }
        else if(this.direction.equals("up")){
            this.y -= this.vel;
        }
        else if(this.direction.equals("down")){
            this.y += this.vel;
        }

    }

}
package ghost;

import processing.core.PImage;
import processing.core.PApplet;
import processing.core.PFont;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.Iterator;
import org.json.simple.JSONArray;
import java.util.AbstractCollection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class Game{


    /**
     * Record the the index of mode length
     */
    private int modeIndex;

    /**
     * Record the the index of frightened list
     */
    private int frightenedIndex;

    /**
     * Record the the second of mode last
     */
    private int second;

    /**
     * Record the the second of result screen
     */
    private int aftersecond;

    /**
     * Record the frame when the frightened start
     */
    private int afterframe;

    /**
     * Record the result screent last second
     */
    private int frightenedSecond;

    /**
     * Record the frightened mode last time
     */
    private int frightenedTime;

    /**
     * Check if the ghost if chase or not
     */
    private boolean chase;

    /**
     * if the game is over or not
     */
    private boolean gameover;

    /**
     * If the ghost need to maintain frightened mode
     */
    private boolean shouldFrightened;

    /**
     * Check that if debug mode should be active
     */
    private boolean debug;

    /**
     * Check that if invisiable mode should be active
     */
    private boolean shouldInvisiable;

    /**
     * Wall list
     */
    private List<Ghost> ghosts;

    /**
     * Fruit list
     */
    private List<Fruit> fruits;

    /**
     * The ghost which is invisiable now
     */
    private List<Ghost> invisiableGhost;

    /**
     * The framecount of invisiable ghost when it is start to be invisiable
     */
    private List<Integer> invisiableLength;

    /**
     * The wall need to be added into list
     */
    private Wall wall;

    /**
     * The fruit need to be added into list
     */
    private Fruit fruit;

    /**
    The player
     */
    private Player player;

    /**
    The ghost
     */
    private Ghost ghost;
    
    /**
    The Consyructor od Game class
     */
    public Game(){
        this.modeIndex = 0;
        this.frightenedIndex = 0;
        this.frightenedSecond = 0;
        this.frightenedTime = 0;
        this.second = 0;
        this.chase = false;
        this.debug = false;
        this.gameover = true;
        this.shouldInvisiable = false;
        this.afterframe = 0;
        this.aftersecond = 0;
        this.shouldFrightened = false;
        this.fruits = new ArrayList<Fruit>();
        this.ghosts = new ArrayList<Ghost>();
        this.invisiableLength = new ArrayList<Integer>();
        this.invisiableGhost = new ArrayList<Ghost>();

    }

    /**
     * Get the map name from json file
     * @return The String of map file name
     */
    public String GetFileName(){ // get the map file name from json file

        JSONParser parser = new JSONParser();
        String filename = null;

        try (Reader reader = new FileReader("config.json")) { // get config in

            JSONObject jsonObject = (JSONObject) parser.parse(reader);

            filename = (String) jsonObject.get("map"); // get the map filename from config

        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        catch (ParseException e) {
            e.printStackTrace();
        }

        return filename;

    }

    /**
     * Get the player velcity from json file
     * @return The long of player velcity
     */
    public long getVel(){ // get waka speed from json file

        JSONParser parser = new JSONParser();
        long vel = 0;

        try (Reader reader = new FileReader("config.json")) {

            JSONObject jsonObject = (JSONObject) parser.parse(reader);

            vel = (long) jsonObject.get("speed"); // get the speed from the json file

        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        catch (ParseException e) {
            e.printStackTrace();
        }

        return vel;
    }

    /**
     * Get the player lives from json file
     * @return The long of player lives
     */
    public long getLives(){ // get waka lives from json file

        JSONParser parser = new JSONParser();
        long lives = 0;

        try (Reader reader = new FileReader("config.json")) {

            JSONObject jsonObject = (JSONObject) parser.parse(reader);

            lives = (long) jsonObject.get("lives"); // get the speed from the json file

        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        catch (ParseException e) {
            e.printStackTrace();
        }

        return lives;
    }

    /**
     * Get the scatter and chase time length from json file
     * @return The list of integer contains the mode length
     */
    public List<Integer> getMode(){ // get waka speed from json file

        List<Integer> mode = new ArrayList<Integer>();

        JSONParser parser = new JSONParser();

        try (Reader reader = new FileReader("config.json")) {

            JSONObject jsonObject = (JSONObject) parser.parse(reader);
            JSONArray array = (JSONArray) jsonObject.get("modeLengths");

            for(int i=0; i < array.size(); i++) {
                mode.add(Integer.parseInt(array.get(i).toString()));
            }

        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        catch (ParseException e) {
            e.printStackTrace();
        }

        return mode;
    }

    /**
     * Get the frightened time length from json file
     * @return The list of integer contains the mode length
     */
    public List<Integer> getFrightenedMode(){ // get frightened mode from json file

        List<Integer> fmode = new ArrayList<Integer>();

        JSONParser parser = new JSONParser();

        try (Reader reader = new FileReader("config.json")) {

            JSONObject jsonObject = (JSONObject) parser.parse(reader);
            JSONArray array = (JSONArray) jsonObject.get("frightenedLength");

            for(int i=0; i < array.size(); i++) {
                fmode.add(Integer.parseInt(array.get(i).toString()));
            }

        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        catch (ParseException e) {
            e.printStackTrace();
        }

        return fmode;
    }


    /**
     * Get the invisiable time length from json file
     * @return The list of integer contains the mode length
     */
    public long getInvisiableMode(){ // get frightened mode from json file

        long invisiable = 0;

        JSONParser parser = new JSONParser();

        try (Reader reader = new FileReader("config.json")) {

            JSONObject jsonObject = (JSONObject) parser.parse(reader);
            invisiable = (long) jsonObject.get("invisiableLength"); // get the speed from the json file

        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        catch (ParseException e) {
            e.printStackTrace();
        }

        return invisiable;
    }

    /**
     * Get the map list from json file and convert it into char array
     * @return The char array of map
     */
    public List<char[]> GetMap(){ // return the list of character of the map

        String filename = this.GetFileName();
        List<char[]> list_list = new ArrayList<char[]>();

        try{
            File f = new File(filename);
            Scanner keyboard = new Scanner(f);

            while(keyboard.hasNextLine()){ // read the map file and get all elements
                String line = keyboard.nextLine();
                char[] list = line.toCharArray(); // make rows into chars
                list_list.add(list);
            }
        }
        catch(FileNotFoundException e){
		}

        return list_list;
    }


    /**
     * @param app The app class for loading picture
     * Find the position of walls
     * @return The list of walls
     */
    public List<Wall> getWallPosition(PApplet app){ // creat an two dimension array to store wall position for waka and fruit to use

        List<char[]> list_list = GetMap();
        List<Wall> walls = new ArrayList<>();

        for(int i = 0; i < list_list.size(); i++){
            for(int j = 0; j < list_list.get(i).length; j++){ // load all image of wall

                if(list_list.get(i)[j] == '1'){
                    this.wall = new Wall(j*16,i*16,app.loadImage("src/main/resources/horizontal.png"));
                    walls.add(this.wall);
                }
                else if(list_list.get(i)[j] == '2'){
                    this.wall = new Wall(j*16,i*16,app.loadImage("src/main/resources/vertical.png"));
                    walls.add(this.wall);
                }
                else if(list_list.get(i)[j] == '3'){
                    this.wall = new Wall(j*16,i*16,app.loadImage("src/main/resources/upLeft.png"));
                    walls.add(this.wall);
                }
                else if(list_list.get(i)[j] == '4'){
                    this.wall = new Wall(j*16,i*16,app.loadImage("src/main/resources/upRight.png"));
                    walls.add(this.wall);
                }
                else if(list_list.get(i)[j] == '5'){
                    this.wall = new Wall(j*16,i*16,app.loadImage("src/main/resources/downLeft.png"));
                    walls.add(this.wall);
                }
                else if(list_list.get(i)[j] == '6'){
                    this.wall = new Wall(j*16,i*16,app.loadImage("src/main/resources/downRight.png"));
                    walls.add(this.wall);
                }
            }
        }

        return walls;
    }


    /**
     * @param app The app class for loading picture
     * Find the position of fruits
     * @return The list of fruits
     */
    public List<Fruit> getAllFruits(PApplet app){

        List<char[]> list_list = GetMap();
        List<Fruit> fruits = new ArrayList<Fruit>();

        for(int i = 0; i < list_list.size(); i++){
            for(int j = 0; j < list_list.get(i).length; j++){

                if(list_list.get(i)[j] == '7'){ // load all image of fruit
                    this.fruit = new Fruit(j*16,i*16,app.loadImage("src/main/resources/fruit.png"));
                    fruits.add(this.fruit);
                }
                if(list_list.get(i)[j] == '8'){ // load all image of fruit
                    this.fruit = new Fruit(j*16,i*16,app.loadImage("src/main/resources/fruit.png"));
                    this.fruit.superFruit();
                    fruits.add(this.fruit);
                }
            }
        }

        this.fruits = fruits;

        return this.fruits;
    }


    /**
     * @param app The app class for load image
     * @return The List of sodacan
     * Get the Sodacan list from map
     */
    public List<SodaCan> getSodacan(PApplet app){

        List<char[]> list_list = GetMap();
        List<SodaCan> sodaCans = new ArrayList<SodaCan>();

        for(int i = 0; i < list_list.size(); i++){
            for(int j = 0; j < list_list.get(i).length; j++){

                if(list_list.get(i)[j] == 's'){ // load all image of fruit
                    SodaCan sodaCan = new SodaCan(j*16,i*16,app.loadImage("src/main/resources/sodacan.png"));
                    sodaCans.add(sodaCan);
                }
            }
        }

        return sodaCans;
    }


    /**
     * @param app The app class for loading picture
     * @param code The key code from keyboard
     * Find the initial position of player, set the velocity of player, if the code is space, active debug mode
     * @return The player
     */
    public Player getPlayer(PApplet app, int code){

        long vel = this.getVel();
        List<char[]> list_list = GetMap();

        if(code == -1){ // init player
            for(int i = 0; i < list_list.size(); i++){
                for(int j = 0; j < list_list.get(i).length; j++){
                    if(list_list.get(i)[j] == 'p'){
                        this.player = new Player(j*16,i*16, app.loadImage("src/main/resources/playerLeft.png"), app.loadImage("src/main/resources/playerClosed.png"),"left", this.getWallPosition(app));
                    }
                }
            }
        }

        else if(code == 37){ // if the input is 37, need to go left
            int x = this.player.getX();
            int y = this.player.getY();
            
            this.player.move("left");
        }

        else if(code == 39){ // if the input is 39, need to go right

            int x = this.player.getX();
            int y = this.player.getY();

            this.player.move("right");
        }

        else if(code == 38){ // if the input is 38, need to go up

            int x = this.player.getX();
            int y = this.player.getY();

            this.player.move("up");
        }

        else if(code == 40){ // if the input is 40, need to go down

            int x = this.player.getX();
            int y = this.player.getY();

            this.player.move("down");
        }

        else if(code == 32){ // if the input is 32, active debug mode
            if(!this.debug){
                this.debug = true;
            }
            else{
                this.debug = false;
            }
        }

        this.player.savePicture(app.loadImage("src/main/resources/playerLeft.png"), app.loadImage("src/main/resources/playerRight.png"), app.loadImage("src/main/resources/playerDown.png"),app.loadImage("src/main/resources/playerUp.png"), app.loadImage("src/main/resources/playerClosed.png"));
        this.player.setVel(vel);

        return this.player;
    }

    /**
     @return If the debug mode is active now
     */
    public boolean getDebugorNot(){
        return this.debug;
    }


    /**
     * @param ghosts The list of ghosts
     * @param app The app class
     * Draw a line between the ghost position with the ghost destination position 
     */
    public void debug(List<Ghost> ghosts, PApplet app){

        for(Ghost ghost : ghosts){
            app.stroke(255,255,255);
            app.line(ghost.getX(),ghost.getY(), ghost.getDesx(), ghost.getDesy());
        }
    }


    /**
     * @param app The app class for loading picture
     * Find the initial position of ghsots, set the velocity of ghost
     * @return The list of ghosts
     */
    public List<Ghost> getGhosts(PApplet app){

        List<char[]> list_list = GetMap();
        List<Ghost> ghosts = new ArrayList<Ghost>();
        long vel = this.getVel();

        for(int i = 0; i < list_list.size(); i++){
            for(int j = 0; j < list_list.get(i).length; j++){
                if(list_list.get(i)[j] == 'a'){
                    this.ghost = new GhostAmbusher(j*16,i*16, app.loadImage("src/main/resources/ambusher.png"), app.loadImage("src/main/resources/frightened.png"), this.getWallPosition(app), "ambusher");
                    this.ghost.setVel(vel);
                    ghosts.add(this.ghost);
                }

                else if(list_list.get(i)[j] == 'c'){
                    this.ghost = new GhostChaser(j*16,i*16, app.loadImage("src/main/resources/chaser.png"), app.loadImage("src/main/resources/frightened.png"), this.getWallPosition(app), "chaser");
                    this.ghost.setVel(vel);
                    ghosts.add(this.ghost);
                }

                else if(list_list.get(i)[j] == 'i'){
                    this.ghost = new GhostIgnorant(j*16,i*16, app.loadImage("src/main/resources/ignorant.png"), app.loadImage("src/main/resources/frightened.png"), this.getWallPosition(app), "ignorant");
                    this.ghost.setVel(vel);
                    ghosts.add(this.ghost);
                }

                else if(list_list.get(i)[j] == 'w'){
                    this.ghost = new GhostWhim(j*16,i*16, app.loadImage("src/main/resources/whim.png"), app.loadImage("src/main/resources/frightened.png"), this.getWallPosition(app), "whim");
                    this.ghost.setVel(vel);
                    ghosts.add(this.ghost);
                }
            }
        }

        return ghosts;
    }


    /**
     * @param ghosts The ghost list from app
     * @param player The player from app
     * @param app The app class for draw line in debug mode
     * Check if the ghost and player collision, if it is and frightened mode, return false and the ghost will be eaten. If it isn't frightened mode, the player will be die, retuen true
     * Check that if the debug mode should be active then call debug() methos
     * @return The die true or false
     */
    public boolean checkFail(List<Ghost> ghosts, Player player, PApplet app){

        boolean die = false;

        if(this.debug){
            this.debug(ghosts, app);
        }

        for(Ghost ghost : ghosts){

            if( ghost.getX() + 28 >= player.getX() && ghost.getX() <= player.getX() + 16 && ghost.getY() + 28 >= player.getY() && ghost.getY() <= player.getY() + 16 ){ // if the player contact the any ghost
                die = true;

                if(ghost.getMode().equals("frightened")){ // if the ghost is at frightened mode, the player will not die
                    ghost.eat();
                    this.ghosts = ghosts;   
                    return false;
                }
                break;
            }

        }
        this.ghosts = ghosts;

        if(die){ // if the ghost will not be eat return true
            return true;
        }
        else{
            return false;
        }
    }


    /**
     * @return The ghost list after changed
     */
    public List<Ghost> nowGhost(){
        return this.ghosts;
    }


    /**
     * @param wallsDraw Wall list from app class
     * @param app The app class for draw
     * Drwa all wall on screen
     */
    public void drawWall(List<Wall> wallsDraw, PApplet app){
        for(Wall wall : wallsDraw){
            wall.draw(app);
        }
    }


    /**
     * @param player Player from app class
     * @param app The app class for draw
     * @param frameCount The frameCount for calculate second
     * Draw player with open mouth and clouse mouth
     */
    public void drawPlayer(Player player, PApplet app, int frameCount){

        if ((frameCount / 8) % 2 == 0){
            player.draw(app,"close");
        }
        else{
            player.draw(app,"open");
        }
    }


    /**
     * @param fruits The fruit list from App
     * @param player The player from app
     * @param app The app class for draw
     * Draw the fruits, if the player position is equal to the furit fruit, the furit is eaten
     * @return The list of changed fruit
     */
    public List<Fruit> drawFruit(List<Fruit> fruits, Player player, PApplet app){

        for(Fruit fruit : fruits){
            if(fruit.getX() == player.getX() && fruit.getY() == player.getY()){
                fruit.eaten();
            }
            fruit.draw(app);
        }

        return fruits;
    }
    
    /**
     * @param sodacans The sodacan list from App
     * @param ghosts The ghost list from App
     * @param app The app class for draw
     * @param frameCount The frameconut fron app
     * Draw the sodacan on the screen, if the ghost position is equals to the sodacan position and the ghost mode is frighten, the sodacan will be eaten
     * Check the time of invisiable period, is the time is eaqual to the invisiable length inside json file, the ghost will be recalled
     * @return The list of sodacan that being changed
     */
    public List<SodaCan> drawSodacan(List<SodaCan> sodacans, List<Ghost> ghosts, int frameCount, PApplet app){

        for(SodaCan sodacan : sodacans){
            for(Ghost ghost : ghosts){
                if(ghost.getX() == sodacan.getX() && ghost.getY() == sodacan.getY() && ghost.getMode().equals("frightened") && ! ghost.alreadyInvisiable() && !sodacan.iseaten()){ // if the ghost pick up sodacan

                    sodacan.eaten();
                    ghost.invisiable();
                    this.shouldInvisiable = true;
                    this.invisiableLength.add(frameCount); // pass the frameCount that the sodacan is eaten
                    this.invisiableGhost.add(ghost); // pass the ghost that eat sodacan
                }
            }
            sodacan.draw(app);
        }

        this.ghosts = ghosts;

        if(this.invisiableLength.size() > 0 && this.invisiableGhost.size() > 0){ // if there is any ghost is in frightened mode
            
            for(int i = 0; i < this.invisiableLength.size(); i++){

                if(frameCount - this.invisiableLength.get(i) == this.getInvisiableMode() * 60 && this.invisiableGhost.size() > 0){ // check time

                    for(Ghost ighost : this.ghosts){

                        if(this.invisiableGhost.get(i).getPeople().equals(ighost.getPeople())){

                            ighost.show();
                            this.invisiableGhost.remove(i);
                            this.invisiableLength.remove(i);
                            
                            if(this.invisiableGhost.size() == 0){
                                break;
                            }
                        }
                    }
                }
            }
        }

        this.ghosts = ghosts;
        return sodacans;
    }


    /**
     * @param fruitsFromApp The fruit list from app
     * @param frameCount The frameCount from app
     * @return A list of different string, the first item in list is the ghost mode, the second one is the game win or not
     * If do not in frightened mode, then the second will be recorded and calculate for the deciding of sactter or chaser
     * If the super fruit is eaten, the shoudFrightened will become true, and all ghost will strat the frightened mode for the specified time in mode list.
     * If all fruit is eaten, the second item inside pf return list shoule be true
     */
    public List<String> ghostModeWin(List<Fruit> fruitsFromApp, int frameCount) {

        List<Integer> mode = this.getMode();
        boolean win = true;
        boolean superEaten = false;
        boolean fail = false;
        String ghostMode = "";
        List<Integer> frightened = this.getFrightenedMode(); 
        List<String> shouldReturn = new ArrayList<String>(); // index 0 is the ghost mode. index 1 is win or not

        if(!this.shouldFrightened){ // check the time to decide chase or scatter
            if(frameCount % 60 == 0){
                this.second ++;
            }

            if(second == mode.get(this.modeIndex)){
                second = 0;
                this.modeIndex++;
                this.chase = ! this.chase;
            }

            if(this.modeIndex == mode.size()){
                this.modeIndex = 0;
            }

            if(this.chase){
                ghostMode = "chase";
            }
            else{
                ghostMode = "scatter";
            }
        }

        for(Fruit fruit : fruitsFromApp){ // check that if it need to get frightened
            if(fruit.iseaten()){
                if(fruit.ifSuper() && fruit.shouldFrightened()){
                    superEaten = true;
                    fruit.alreadyFrightened();
                }
            }
            else{
                win = false;
            }
        }

        if(superEaten){
            this.shouldFrightened = true;
            this.frightenedTime = frameCount;
        }
        
        if(this.shouldFrightened){ // if any ghost should frightened, record time

            if((frameCount - this.frightenedTime) % 60 == 1){
                this.frightenedSecond ++;
            }

            if(this.frightenedSecond == frightened.get(this.frightenedIndex)){
                this.frightenedSecond = 0;
                this.frightenedIndex++;
                this.shouldFrightened = false;
                this.frightenedTime = 0;
            }

            if(this.frightenedIndex == frightened.size()){
                this.frightenedIndex = 0;
            }
        }

        if(this.shouldFrightened){
            ghostMode = "frightened";
        }

        shouldReturn.add(ghostMode);
        
        if(win){ // if all fruits eaten, return true, game win
            shouldReturn.add("true");
        }
        else{
            shouldReturn.add("false");
        }

        return shouldReturn;
    }

    /**
     * @param app is the first parameter, which is needed needed to write text
     * @param font is the second parameter, which is the font need to print on the result screen
     * @param frameCount is the third parameter, which is needed to calculate the second that result screen represent
     * @param win is the forth parameter, which is needed to check print win or game over
     * if the game is over, record the frameCount, for calculating the second the result screen print. if the frameCount between the moment and the frame recorded before, the second should plus one, when second equals to the value of frightened length, the method should return true, else will return false;
     * @return return if this game need to restart
    */
    public boolean restart(PApplet app, PFont font, int frameCount, boolean win) {
        if(this.gameover){
            this.gameover = false;
            this.afterframe = frameCount;
        }

        int frame = frameCount - this.afterframe;

        if(frame / 60 == 1){ // record time, if the frame is 60, second + 1
            this.aftersecond ++;
            this.afterframe += 60;
        }

        this.debug = false;

        app.textFont(font);
        app.textSize(32);

        if(win){
            app.text("YOU WIN",100,300);
        }
        else{
            app.text("GAME OVER",80,300);
        }

        if(this.aftersecond / 10 == 1){ // if it is already 10 second
            this.aftersecond -= 10;
            this.gameover = true;
            return true;
        }
        else{
            return false;
        }
    }

}
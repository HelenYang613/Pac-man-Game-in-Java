package ghost;

import processing.core.PImage;
import processing.core.PApplet;
import java.util.ArrayList;
import java.util.List;

public class Player{

    /**
     * The row oosition of player
     */
    private int x;

    /**
     * The column oosition of player
     */
    private int y;

    /**
     * The velocity
     */
    private long vel;

    /**
     * The move direction
     */
    private String direction;

    /**
     * Save the direction need to be moved next time
     */
    private String waitDirection;

    /**
     * Check that if the player will collision
     */
    private boolean collision;

    /**
     * Check that if the movement can be move or not
     */
    private boolean test;

    /**
     * Check that if the movement need to move for next possible
     */
    private boolean wait;

    /**
     * Check that if the save position can be moves or not
     */
    private boolean next;

    /**
     * The app class for draw
     */
    private App app;

    /**
     * The wall list of all walls
     */
    private List<Wall> walls;

    /**
     * The left open picture
     */
    private PImage pictureleft;

    /**
     * The right open picture
     */
    private PImage pictureright;

    /**
     * The up open picture
     */
    private PImage pictureup;

    /**
     * The down open picture
     */
    private PImage picturedown;

    /**
     * The first picture
     */
    private PImage picture;

    /**
     * The close picture
     */
    private PImage close;

    /**
     * Constructor of Player, contains six paramters
     * @param x The row position of player
     * @param y The column position of player
     * @param picture The first picture of player
     * @param close The close picture of player
     * @param direction The direction of player
     * @param walls The walls from json file from map
     */
    public Player(int x, int y, PImage picture, PImage close, String direction, List<Wall> walls) {

        this.x = x;
        this.y = y;
        this.vel = 0;
        this.direction = direction;
        this.waitDirection = "wait";

        this.picture = picture;
        this.close = close;

        this.collision = false;
        this.test = false;
        this.wait = false;
        this.next = true;
        this.app = new App();
        this.walls = walls;

    }


    /**
     * @param pictureleft is the picture of left open
     * @param pictureright is the picture of right open
     * @param pictureup is the picture of up open
     * @param picturedown is the picture of down open
     * @param close is the picture of close
     * Save all picture into player
     */
    public void savePicture(PImage pictureleft,PImage pictureright,PImage picturedown,PImage pictureup, PImage close){
        this.pictureleft = pictureleft;
        this.pictureright = pictureright;
        this.picturedown = picturedown;
        this.pictureup = pictureup;
        this.close = close;
    }

    /**
     * Move the player, if the player need to wait for next possible, keep check that if the next possible is coming or not
     */
    public void tick(){

        if(this.wait){
            this.checkCollision(this.waitDirection,"wait");

            if(!this.next){
                this.direction = this.waitDirection;
            }
        }

        this.checkCollision(this.direction,"real");

        if((this.direction.equals("left") && !this.collision)){
            this.x -= this.vel;
        }

        else if((this.direction.equals("right") && !this.collision)){
            this.x += this.vel;

        }

        else if((this.direction.equals("up") && !this.collision)){
            this.y -= this.vel;
        }

        else if((this.direction.equals("down") && !this.collision)){   
            this.y += this.vel;
        }

    }


    /**
    @param speed is the speed from json file
    set the velocity of player
     */
    public void setVel(long speed){
        this.vel = speed;
    }

    /**
     * @return The value of velocity
     */
    public long getVel(){
        return this.vel;
    }


    /**
    @return the row position of player
     */
    public int getX(){
        return this.x;
    }


    /**
    @return the column position of player
     */
    public int getY(){
        return this.y;
    }


    /**
    @return the moving direction of player
     */
    public String getDirection(){
        return this.direction;
    }


    /**
     * @return The test direction will collision or not
     */
    public boolean test(){
        return this.test;
    }

    /**
     * @return The real direction will collision or not
     */
    public boolean collision(){
        return this.collision;
    }

    /**
     * @return The player need to wait or not
     */
    public boolean waitReturn(){
        return this.wait;
    }

    /**
     * @return The player need to wait for next possible or not
     */
    public boolean next(){
        return this.next;
    }


    /**
     * @param str The direction string
     * Check if player will collision and if it need to wait for the next possible
     */
    public void move(String str){
        this.checkCollision(str,"test");

        this.wait = false;

        if(!this.test){
            this.direction = str;
        }
        else{
            this.waitDirection = str;
            this.wait = true;
        }
    }


    /**
     * @param testdirection Pass the direction should been tested
     * @param realortest Decide which needed to be changed, the real direction, test direction, or the next direction
     * Check if the player will collision to the wall and change the attribute, if realortest is real, the collision will be true, if it is test, the test will true, if it is next, the next should be true
     */
    public void checkCollision(String testdirection, String realortest){

        this.collision = false;
        this.test = false;
        this.next = false;

        for(Wall wall : this.walls){

            int cLeftUp = this.x; // the column of left up corner
            int rLeftUp = this.y; // the row of left up corner

            int cLeftDown = this.x; //  the column
            int rLeftDown = this.y + 16; // the row 

            int cRightUp = this.x + 16; // the column
            int rRightUp = this.y; // the row
            
            int cRightDown = this.x + 16; // the column 
            int rRightDown = this.y + 16; // the row

            int cwallLeftUp = wall.getX(); // the column
            int rwallLeftUp = wall.getY(); // the row

            int cwallLeftDown = wall.getX(); // the column
            int rwallLeftDown = wall.getY() + wall.getHeight(); // the row

            int cwallRightUp = wall.getX() + wall.getWidth(); // the column
            int rwallRightUp = wall.getY(); // the row

            int cwallRightDown = wall.getX() + wall.getWidth() ; // the column
            int rwallRightDown = wall.getY() + wall.getHeight(); // the row

            
            if(testdirection.equals("left")){
                if((rLeftUp < rwallRightDown && rLeftUp >= rwallRightUp && cLeftDown == cwallRightDown) || (rLeftDown <= rwallRightDown && rLeftDown > rwallRightUp && cLeftDown == cwallRightDown)) {

                    if(realortest.equals("real")){
                        this.collision = true;
                    }

                    else if(realortest.equals("test")){
                        this.test = true;
                    }

                    else if(realortest.equals("wait")){
                        this.next = true;
                    }

                    break;
                }
            }

            else if(testdirection.equals("right")){
                if((rRightUp < rwallLeftDown && rRightUp >= rwallLeftUp && cRightDown == cwallLeftDown) || (rRightDown <= rwallLeftDown && rRightDown > rwallLeftUp && cRightDown == cwallLeftDown)) {

                    if(realortest.equals("real")){
                        this.collision = true;
                    }

                    else if(realortest.equals("test")){
                        this.test = true;
                    }

                    else if(realortest.equals("wait")){
                        this.next = true;
                    }

                    break;
                }
            }

            else if(testdirection.equals("up")){

                if((cLeftDown >= cwallLeftDown && cLeftDown < cwallRightDown && rLeftUp == rwallRightDown) || (cRightDown > cwallLeftDown && cRightDown <= cwallRightDown && rLeftUp == rwallRightDown)){

                    if(realortest.equals("real")){
                        this.collision = true;
                    }

                    else if(realortest.equals("test")){
                        this.test = true;
                    }

                    else if(realortest.equals("wait")){
                        this.next = true;
                    }

                    break;
                }
            }

            else if(testdirection.equals("down")){
                if((cLeftDown >= cwallLeftUp && cLeftDown < cwallRightUp && rLeftDown == rwallRightUp) || (cRightDown > cwallLeftUp && cRightDown <= cwallRightUp && rLeftDown == rwallRightUp)){

                    if(realortest.equals("real")){
                        this.collision = true;
                    }

                    else if(realortest.equals("test")){
                        this.test = true;
                    }

                    else if(realortest.equals("wait")){
                        this.next = true;
                    }

                    break;
                }
            }
        }

    }


    /**
     * @param app The PApplet for draw image
     * @param string Decide which picture should be printed
     */
    public void draw(PApplet app, String string){

        if(string.equals("open")){

            if(this.direction.equals("left")){
                app.image(this.pictureleft,this.x-1,this.y-4);
            }
            else if(this.direction.equals("right")){
                app.image(this.pictureright,this.x-1,this.y-4);
            }
            else if(this.direction.equals("up")){
                app.image(this.pictureup,this.x-1,this.y-4);
            }
            else if(this.direction.equals("down")){
                app.image(this.picturedown,this.x-1,this.y-4);
            }
            
        }
        else{
            app.image(this.close,this.x-1,this.y-4);
        }
    }
}
package ghost;

import processing.core.PImage;
import processing.core.PApplet;

public class SodaCan {

    /**
     * The row position of fruit
     */
    private int x;

    /**
     * The column position of fruit
     */
    private int y;
    
    /**
    * The boolean record if fruit is eaten or not, if it is eaten, is will be true and won't be draw
     */
    private boolean eaten;

    /**
     * The boolean to distinguish if the ghost is frightened for the eaten of this suoer fruit
     */
    private boolean shouldInvisiable;

    /**
     * The image of fruit
     */
    private PImage picture;

    /**
     * Constructor of Fruit, contains three parameters
     * @param x The row position of fruit
     * @param y The column position of fruit
     * @param picture The picture of fruit
     */
    public SodaCan(int x, int y, PImage picture){
        this.x = x;
        this.y = y;
        this.picture = picture;
        this.eaten = false;
        this.shouldInvisiable = true;
    }

    /**
     * @return The row position of fruit
     */
    public int getX(){
        return this.x;
    }

    /**
     * @return The column position of fruit
     */
    public int getY(){
        return this.y;
    }

    /**
     * change the eaten arrtibuate to true, so that fruit will not be drawn
     */
    public void eaten(){
        this.eaten = true;
    }

    /**
     * @return The eaten or not condition of fruit
     */
    public boolean iseaten(){
        return this.eaten;
    }

    /**
     * set the fruit as already frightened
     */
    public void alreadyInvisiable(){
        this.shouldInvisiable = false;
    }

    /**
     * @return The already frighented or not condition of fruit
     */
    public boolean shouldInvisiable(){
        return this.shouldInvisiable;
    }

    /**
     * @param app The PApplet for draw image
     * Draw the prcture
     */
    public void draw(PApplet app){

        if(!this.eaten){
            app.image(this.picture,this.x,this.y);
        }
    }
}
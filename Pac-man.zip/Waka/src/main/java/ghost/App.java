package ghost;
import processing.core.PImage;
import processing.core.PApplet;
import processing.core.PFont;
import java.util.ArrayList;
import java.util.List;

public class App extends PApplet {

    /**
    The static final int record the screen width
     */
    public static final int WIDTH = 448;

    /**
    The static final int record the screen length
     */
    public static final int HEIGHT = 576;

    /**
    The wall list recorded every wall
     */
    private List<Wall> walls;

    /**
    The fruit list recorded every fruit
     */
    private List<Fruit> fruits;

    /**
     * Record the list of sodacan
     */
    private List<SodaCan> sodacans;

    /**
    The ghost list recorded every ghost
     */
    private List<Ghost> ghosts;

    /**
    The player class
     */
    private Player player;

    /**
    The game class that needed in the class
     */
    private Game game;

    /**
    record the waka rest lives
     */
    private long lives;

    /**
    record the x position of chaser
     */
    private int chaserx;

    /**
    record the y position of chaser
     */
    private int chasery;

    /**
    The font need to be print on the result screent
     */
    private PFont font;

    /**
    Constructor for App class
     */

    public App() {
        this.game = new Game();
        this.walls = new ArrayList<Wall>();
        this.fruits = new ArrayList<Fruit>();
        this.sodacans = new ArrayList<SodaCan>();
        this.chaserx = 0;
        this.chaserx = 0;
        this.lives = 0;
    }


    /**
    set pictures, initialize the game class
     */
    public void setup() {
        frameRate(60);
        this.game = new Game();
        this.lives = game.getLives();
        this.walls = game.getWallPosition(this);
        this.fruits = game.getAllFruits(this);
        this.sodacans = game.getSodacan(this);
        this.player = game.getPlayer(this, -1);
        this.ghosts = game.getGhosts(this);
        this.font = createFont("src/main/resources/PressStart2P-Regular.ttf", 12);
    }

    /**
     * Set the width and height of window
     */
    public void settings() {
        size(WIDTH, HEIGHT);
    }


    /**
    pass the key code into game class, getPlayer method
     */
    public void keyPressed(){ //if there is any key arrow input
        int code = keyCode;
        this.player = game.getPlayer(this, code);
    }

    /**
    * check the player is win or not
    * if the player is contacted ghost, decide if player will lose life or one of the ghost needed to be recalled
    * if the player life less than 1, should call methond inside game class to print screen and restart
    * if the player is win, should call methond inside game class to print screen and restart
    * if the player neither win nor fail, print wall, fruit, player, and ghost. if the player equals to any fruit position, the fruit needed to be eaten and never print on the screen, print the rest left of waka, pass the mode string into ghost, pass chase position to whim, and the player and ghost tick.
     */
    public void draw() { 
        background(0, 0, 0);
        boolean win = false;
        List<String> ghostModeWin = new ArrayList<String>();
        boolean die = this.game.checkFail(this.ghosts, this.player, this);
        this.ghosts = this.game.nowGhost(); // get new ghosts after the change of frightened or not
        ghostModeWin = this.game.ghostModeWin(this.fruits,frameCount); // get ghost mode and win or not

        if(ghostModeWin.get(1).equals("true")){
            win = true;
        }

        if(die){
            boolean recall = false; // if need to recall rather than player lose life, recall should be true, else should be recall

            for(Ghost ghost: this.ghosts){
                if(ghost.isEaten() && ! recall){ // check that if there is any ghost can be recalled
                    ghost.recall();
                    recall = true;
                    this.player = this.game.getPlayer(this, -1);
                    break;
                }
            }

            if(!recall){ // no ghost was recalled, the player will lose live
                this.lives -= 1;
                this.player = this.game.getPlayer(this, -1);
            }
        }

        if(this.lives < 1){
            if(this.game.restart(this, this.font, frameCount, false)){ // the restart is true
                this.setup();
            }
        }
        if(win){
            if(this.game.restart(this, this.font, frameCount, true)){ // the restart is true
                this.setup();
            }
        }

        if(! (this.lives < 1) && ! win){
            this.game.drawWall(this.walls, this);
            this.fruits = this.game.drawFruit(this.fruits, this.player, this);
            this.sodacans = this.game.drawSodacan(this.sodacans, this.ghosts, frameCount ,this);
            this.ghosts = this.game.nowGhost(); // get new ghosts after the change of sodacan

            for(long i = this.lives -2 ; i >= 0; i--){
                this.image(this.loadImage("src/main/resources/playerRight.png"),i * 24, 545);
            }
            for(Ghost ghost : this.ghosts){
                ghost.mode(ghostModeWin.get(0), this.player); // ghosts get mode
                ghost.tick();
                if(ghost.getPeople().equals("chaser")){ // save chase position for whim
                    this.chaserx = ghost.getX();
                    this.chasery = ghost.getY();
                }
                if(ghostModeWin.get(0).equals("chase") && ghost.getPeople().equals("whim")){
                    ghost.setChaser(chaserx, chasery);
                }
                ghost.draw(this);
            }
            this.player.tick();
            this.game.drawPlayer(this.player, this, frameCount);
        }
    }

    public static void main(String[] args) {
        PApplet.main("ghost.App");
    }
}

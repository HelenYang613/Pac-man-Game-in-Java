package ghost;

import processing.core.PImage;
import processing.core.PApplet;

public class Fruit {


    /**
     * The row position of fruit
     */
    private int x;

    /**
     * The column position of fruit
     */
    private int y;
    
    /**
    * The boolean record if fruit is eaten or not, if it is eaten, is will be true and won't be draw
     */
    private boolean eaten;

    /**
     * The boolean to distinguish if this fruit is super fruit or not
     */
    private boolean superFruit;

    /**
     * The boolean to distinguish if the ghost is frightened for the eaten of this suoer fruit
     */
    private boolean shouldFrightened;

    /**
     * The image of fruit
     */
    private PImage fruit;

    /**
     * Constructor of Fruit, contains three parameters
     * @param x The row position of fruit
     * @param y The column position of fruit
     * @param fruit The picture of fruit
     */
    public Fruit(int x, int y, PImage fruit){
        this.x = x;
        this.y = y;
        this.fruit = fruit;
        this.eaten = false;
        this.superFruit = false;
        this.shouldFrightened = true;
    }

    /**
     * @return The row position of fruit
     */
    public int getX(){
        return this.x;
    }

    /**
     * @return The column position of fruit
     */
    public int getY(){
        return this.y;
    }

    /**
     * change the eaten arrtibuate to true, so that fruit will not be drawn
     */
    public void eaten(){
        this.eaten = true;
    }

    /**
     * @return The eaten or not condition of fruit
     */
    public boolean iseaten(){
        return this.eaten;
    }

    /**
     * set the fruit as a suoer fruit
     */
    public void superFruit(){
        this.superFruit = true;
    }

    /**
     * @return The super or not condition of fruit
     */
    public boolean ifSuper(){
        return this.superFruit;
    }

    /**
     * set the fruit as already frightened
     */
    public void alreadyFrightened(){
        this.shouldFrightened = false;
    }

    /**
     * @return The already frighented or not condition of fruit
     */
    public boolean shouldFrightened(){
        return this.shouldFrightened;
    }

    /**
     * @param app The PApplet for draw image
     * Draw the prcture
     */
    public void draw(PApplet app){

        if(!this.eaten && !this.superFruit){
            app.image(this.fruit,this.x,this.y);
        }

        if(!this.eaten && this.superFruit){
            app.image(this.fruit,this.x,this.y,32,32);
        }
    }
}
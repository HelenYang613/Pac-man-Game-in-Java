package ghost;

import processing.core.PImage;
import processing.core.PApplet;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.lang.Math; 

public class Ghost {

    
    /**
     * The row position
     */
    protected int x;

    /**
     * The column position
     */
    protected int y;

    /**
     * The row position of strat position
     */
    protected int startx;

    /**
     * The column position
     */
    protected int starty;

    /**
     * Save the chaser row position
     */
    protected int chaserx;

    /**
     * Save the chaser column position
     */
    protected int chasery;

    /**
     * The row position of the destination
     */
    protected int desx;

    /**
     * The column position of the destination
     */
    protected int desy;

    /**
     * The ghost normal picture
     */
    protected PImage ghost;

    /**
     * The ghost frightend picture
     */
    protected PImage frightenedPicture;

    /**
     * The ghost type
     */
    protected String people;

    /**
     * The ghost mode
     */
    protected String mode;

    /**
     * The ghost move direction
     */
    protected String direction;

    /**
     * The ghost will collision or not
     */
    protected boolean collision;
    
    /** The ghost is eaten or not
     */
    protected boolean eaten;

    /**
     * Check if the ghost is invisiable
     */
    protected boolean invisiable;

    /**
     * The velocity of ghost
     */
    protected long vel;

    /**
     * The wall list
     */
    protected List<Wall> walls;

    /**
     * the player information
     */
    protected Player player;


    /**
     * The Ghost cnstructor
     * @param x The row position of ghost
     * @param y The column position of ghost
     * @param ghost The picture of ghost
     * @param frightenedPicture The picture of frightened ghost
     * @param walls The walls position for ghost move
     * @param people The string of ghost type
     */
    public Ghost(int x, int y, PImage ghost, PImage frightenedPicture ,List<Wall> walls, String people){
        this.x = x;
        this.y = y;
        this.chaserx = 0;
        this.chasery = 0;
        this.startx = x;
        this.starty = y;
        this.desx = 0;
        this.desy = 0;
        this.ghost = ghost;
        this.frightenedPicture = frightenedPicture;
        this.people = people;
        this.invisiable = false;
        this.eaten = false;
        this.walls = walls;
    }

    
    /**
     * @return the row position of ghost
     */
    public int getX(){
        return this.x;
    }

    /**
     * @return the column position of ghost
     */
    public int getY(){
        return this.y;
    }

    /**
     * @return the row position of destination
     */
    public int getDesx(){
        return this.desx;
    }

    /**
     * @return the column position of destination
     */
    public int getDesy(){
        return this.desy;
    }

    /**
     * set the mode of ghost and the information of player
     * @param mode The mode of ghost, including scatter, chase, frightened
     * @param player The player class for the information of player position
     */
    public void mode(String mode, Player player){
        this.mode = mode;
        this.player = player;
    }

    /**
    @return The mode of ghost
     */
    public String getMode(){
        return this.mode;
    }

    /**
     * set the ghost velocity
     * @param speed The ghost speed
     */
    public void setVel(long speed){
        this.vel = speed;
    }

    /**
     * set the chaser position for chase mode
     * @param x The row position of chaser
     * @param y The column position of chaser
     */
    public void setChaser(int x, int y){
        this.chaserx = x;
        this.chasery = y;
    }

    /**
     * Set the ghost is eaten
     * set the eaten ghost position as (0.0), the direction is null
     */
    public void eat(){
        this.eaten = true;
        this.x = 0;
        this.y = 0;
        this.direction = null;
    }

    /**
     * @return The whim is eaten or ont,if it is eaten, will be true, otherwise will be false
     */
    public boolean isEaten(){
        return this.eaten;
    }

    /**
     * if the whim should be recalled, the x and y position should be same as when it is started
     */
    public void recall(){
        this.eaten = false;
        this.x = this.startx;
        this.y = this.starty;
        this.direction = null;
    }

    /**
     * @return The type of ghost
     */
    public String getPeople(){
        return this.people;
    }

    /**
     * Change that the ghost as invisiable
     */
    public void invisiable() {
        this.invisiable = true;
    }

    /**
     * Change the ghost should not invisiable
     */
    public void show(){
        this.invisiable = false;
    }

    /**
     * @return The condition of the ghost is invisiable or not
     */
    public boolean alreadyInvisiable() {
        return this.invisiable;
    }

    /**
     The move of ghost
     */
    public void tick(){
    }

    /**
     * @param x The ghost row position now
     * @param y The ghost column position now
     * @param nowDirection The ghost move direction now
     * @return The list of all direction that ghost can move
     */
    public List<String> validDirection (int x, int y, String nowDirection){

        List<String> directions = new ArrayList<String>();

        String nextDirection = null;
        boolean test1 = false;
        boolean test2 = false;
        HashMap<String,String> contrary = new HashMap<String,String>();
        contrary.put("left","right");
        contrary.put("right","left");
        contrary.put("up","down");
        contrary.put("down","up");

        if( ! this.checkCollision(x,y, "down") && ! this.checkCollision(x,y + 1, "down") && ! "down".equals(contrary.get(nowDirection))){
            directions.add("down");
        }

        if( !this.checkCollision(x, y, "left") && ! this.checkCollision(x - 1, y, "left") && ! "left".equals(contrary.get(nowDirection))){
            directions.add("left");
        }

        if( ! this.checkCollision(x,y, "right") && ! this.checkCollision(x + 1, y, "right") && ! "right".equals(contrary.get(nowDirection))){
            directions.add("right");
        }
        
        if( ! this.checkCollision(x, y, "up") && ! this.checkCollision(x, y - 1, "up") && ! "up".equals(contrary.get(nowDirection))){
            directions.add("up");
        }
        
        return directions;
    }


    /**
     * @param x The now position of row
     * @param y The now position of column
     * @param positionx The destination of row position 
     * @param positiony The destination of column position 
     * @param nowDirection The recent move direction of ghost
     * Check the next direction of ghost. If goes any direction will not collison, then add thedirection and the distance between destination and player after move into list, and find the shorest one, return it
     * @return The direction of next step
     */
    public String getNearStep(int x, int y, int positionx, int positiony, String nowDirection){

        List<String> directions = new ArrayList<String>();
        List<Double> distanceDirection = new ArrayList<Double>();

        String nextDirection = null;
        boolean test1 = false;
        boolean test2 = false;
        Double distance = Math.sqrt(Math.pow((x - positionx),2) + Math.pow((y - positiony),2));
        HashMap<String,String> contrary = new HashMap<String,String>();
        contrary.put("left","right");
        contrary.put("right","left");
        contrary.put("up","down");
        contrary.put("down","up");

        if( ! this.checkCollision(x,y, "down") && ! this.checkCollision(x,y + 1, "down") && ! "down".equals(contrary.get(nowDirection))){
            directions.add("down");
            distanceDirection.add(Math.sqrt(Math.pow((x - positionx), 2) + Math.pow((y + 1 - positiony),2)));
        }

        if( ! this.checkCollision(x, y, "left") && ! this.checkCollision(x - 1, y, "left") && ! "left".equals(contrary.get(nowDirection))){
            directions.add("left");
            distanceDirection.add(Math.sqrt(Math.pow((x - 1 - positionx), 2) + Math.pow((y - positiony),2 )));
        }

        if( ! this.checkCollision(x,y, "right") && ! this.checkCollision(x + 1, y, "right") && ! "right".equals(contrary.get(nowDirection))){
            directions.add("right");
            distanceDirection.add(Math.sqrt(Math.pow((x + 1 - positionx), 2) + Math.pow((y - positiony),2 )));
        }
        
        if( ! this.checkCollision(x, y, "up") && ! this.checkCollision(x, y - 1, "up") &&  ! "up".equals(contrary.get(nowDirection))){
            directions.add("up");
            distanceDirection.add(Math.sqrt(Math.pow((x - positionx), 2) + Math.pow((y - 1 - positiony),2 )));
        }

        if(distanceDirection.size() > 0){
            distance = distanceDirection.get(0);
            nextDirection = directions.get(0);
        }

        else{
            return nowDirection;
        }

        for(int i = 0; i < distanceDirection.size(); i++){

            if(distanceDirection.get(i) <= distance){
                distance = distanceDirection.get(i);
                nextDirection = directions.get(i);
            }
        }
        
        return nextDirection;
    }

    /**
     * @param x The row position of x
     * @param y The column position of x
     * Check that if the ghost need to decede what is the next direction
     * @return if the ghost need to chose the next direction
     */
    public boolean next(int x, int y){
        List<String> crosssection = new ArrayList<String>();

        String[] directionsstr = new String[]{"left", "right", "up", "down"};

        HashMap<String,String> contrary = new HashMap<String,String>();
        contrary.put("left","right");
        contrary.put("right","left");
        contrary.put("up","down");
        contrary.put("down","up");

        for(int i = 0; i < directionsstr.length; i++){

            if(this.checkCollision(x,y,directionsstr[i])){
                crosssection.add(directionsstr[i]);
            }
        }

        if(crosssection.size() != 2 || (crosssection.size() == 2 && ! crosssection.get(0).equals(contrary.get(crosssection.get(1))))){

            return true;
        }
        else{
            return false;
        }
    }

    /**
     * @param x the check row position
     * @param y the check column position
     * @param testdirection the check direction
     * Check if the ghost will collision if goes to the test direction
     * @return if the ghost will collision if goes to test direction
     */
    public boolean checkCollision(int x, int y, String testdirection){

        this.collision = false;

        for(Wall wall : this.walls){

            int cLeftUp = x; // the column of left up corner
            int rLeftUp = y; // the row of left up corner

            int cLeftDown = x; //  the column
            int rLeftDown = y + 16; // the row 

            int cRightUp = x + 16; // the column
            int rRightUp = y; // the row
            
            int cRightDown = x + 16; // the column 
            int rRightDown = y + 16; // the row

            int cwallLeftUp = wall.getX(); // the column
            int rwallLeftUp = wall.getY(); // the row

            int cwallLeftDown = wall.getX(); // the column
            int rwallLeftDown = wall.getY() + wall.getHeight(); // the row

            int cwallRightUp = wall.getX() + wall.getWidth(); // the column
            int rwallRightUp = wall.getY(); // the row

            int cwallRightDown = wall.getX() + wall.getWidth() ; // the column
            int rwallRightDown = wall.getY() + wall.getHeight(); // the row

            
            if(testdirection.equals("left")){

                if((rLeftUp < rwallRightDown && rLeftUp >= rwallRightUp && cLeftDown == cwallRightDown) || (rLeftDown <= rwallRightDown && rLeftDown > rwallRightUp && cLeftDown == cwallRightDown)) {
                    return true;
                }
            }

            else if(testdirection.equals("right")){

                if((rRightUp < rwallLeftDown && rRightUp >= rwallLeftUp && cRightDown == cwallLeftDown) || (rRightDown <= rwallLeftDown && rRightDown > rwallLeftUp && cRightDown == cwallLeftDown)) {
                    return true;
                }
            }

            else if(testdirection.equals("up")){

                if((cLeftDown >= cwallLeftDown && cLeftDown < cwallRightDown && rLeftUp == rwallRightDown) || (cRightDown > cwallLeftDown && cRightDown <= cwallRightDown && rLeftUp == rwallRightDown)){
                    return true;
                }
            }

            else if(testdirection.equals("down")){

                if((cLeftDown >= cwallLeftUp && cLeftDown < cwallRightUp && rLeftDown == rwallRightUp) || (cRightDown > cwallLeftUp && cRightDown <= cwallRightUp && rLeftDown == rwallRightUp)){
                    return true;
                }
            }
        }

        return false;
    }

    
    /**
     * @param app The PApplet class for draw image
     * Draw the ghost image in frightened mode or normal mode
     */
    public void draw(PApplet app){

        if(!this.eaten && !this.invisiable){
            if(this.mode.equals("frightened")){
                app.image(this.frightenedPicture,this.x-1,this.y-2);
            }
            else{
                app.image(this.ghost,this.x-1,this.y-2);
            }
        }
    }
}
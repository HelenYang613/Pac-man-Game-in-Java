package ghost;
import processing.core.PImage;
import processing.core.PApplet;

public class AppForTest extends PApplet {

    public static final int WIDTH = 448;
    public static final int HEIGHT = 576;

    public AppForTest() {
    }

    public void setup() {
        frameRate(60);
    }

    public void settings() {
        size(WIDTH, HEIGHT);
    }

    public void draw() {
        if(frameCount == 1){
            this.noLoop();
        }
    }

    public static void main(String[] args) {
        PApplet.main("ghost.App");
    }
}
